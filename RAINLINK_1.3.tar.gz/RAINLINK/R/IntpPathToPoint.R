## The RAINLINK package. Retrieval algorithm for rainfall mapping from microwave links 
## in a cellular communication network.
##
## Version 1.3
## Copyright (C) 2022 Aart Overeem
##
## This program is free software: you can redistribute it and/or modify
## it under the terms of the GNU General Public License as published by
## the Free Software Foundation, either version 3 of the License, or
## (at your option) any later version.
##
## This program is distributed in the hope that it will be useful,
## but WITHOUT ANY WARRANTY; without even the implied warranty of
## MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
## GNU General Public License for more details.
##
## You should have received a copy of the GNU General Public License
## along with this program. If not, see <http://www.gnu.org/licenses/>.

#' Subfunction for computing path-averaged rainfall intensities for unique link paths. 
#' A path-averaged rainfall intensity is assigned to a point at the middle of 
#' the link path.
#' @description Subfunction for computing path-averaged rainfall intensities for 
#' unique link paths. The link-based, e.g. a 15-minute path-averaged rainfall 
#' accumulation is converted to a path-averaged rainfall intensity, and subsequently 
#' assigned to a point at the middle of the link path. Path-averaged rainfall 
#' intensities are obtained, so data from full-duplex links are averaged.
#'
#' @param ID Link identifier.
#' @param LocalCartesianCoorSystem Define EPSG code for (local) Cartesian coordinate system (meters).
#' @param Rmean Data frame with mean path-averaged rainfall intensities (mm h\eqn{^{-1}}).
#' @param XEnd Easting of end of links (km).
#' @param XStart Easting of start of links (km).
#' @param YEnd Northing of end of links (km).
#' @param YStart Northing of start of links (km).
#' @return Coordinates of middle of links in (local) Cartesian coordinate system
#' (latitude, longitude) and rainfall intensity (mm h\eqn{^{-1}})).
#' @export IntpPathToPoint
#' @examples
#' IntpPathToPoint(ID=ID,LocalCartesianCoorSystem=28992,Rmean=Rmean,Xend=Xend,XStart=XStart,
#' YEnd=YEnd,YStart=YStart)
#' @author Aart Overeem & Hidde Leijnse
#' @references ''ManualRAINLINK.pdf''
#'
#' Overeem, A., Leijnse, H., and Uijlenhoet, R., 2016: Retrieval algorithm for rainfall mapping from microwave links in a 
#' cellular communication network, Atmospheric Measurement Techniques, 9, 2425-2444, https://doi.org/10.5194/amt-9-2425-2016.


IntpPathToPoint <- function(ID,LocalCartesianCoorSystem,Rmean,XEnd,XStart,YEnd,YStart)
{

	# Determine coordinates of middle of link:
	X_middleLinks <- (XStart + XEnd) / 2
	Y_middleLinks <- (YStart + YEnd) / 2  

	# Determine unique middle of links:
	Coord_dataf <- data.frame(cbind(X_middleLinks, Y_middleLinks))
	Coord_uniq <- unique(Coord_dataf)
	Rainlink <- array(NA, c(length(Coord_uniq[, 1]), 3))

	# Compute average number of unique link paths:
	NrPaths <- (length(Coord_uniq[, 1]))
	
	# Compute average number of unique links (full-duplex links count twice)
	NrLinks <- length(ID)

	# Compute mean path-averaged rainfall intensities for each unique middle of link. 
	# I.e., rainfall intensities from full-duplex links are averaged.
	Rainlink[, 1] <- Coord_uniq[, 1]
	Rainlink[, 2] <- Coord_uniq[, 2]
	for (i in 1 : NrPaths)
	{
		Rainlink[i, 3] <- mean(Rmean[Rainlink[i, 1] == X_middleLinks & Rainlink[i, 2] == Y_middleLinks], na.rm = TRUE)
	}
	
	Rainlink <- as.data.frame(Rainlink)
	colnames(Rainlink) <- c("X", "Y", "RAIN")
	pnts <- 
        data.frame(
        RAIN = Rainlink$RAIN,
        X = Rainlink$X,
        Y = Rainlink$Y)
        Rainlink <- st_as_sf(pnts, crs = LocalCartesianCoorSystem, coords = c("X", "Y"))
	
	return(na.omit(Rainlink))

}

